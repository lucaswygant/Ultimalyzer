/****************************************************************************
** Meta object code from reading C++ file 'datatreewidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../../datatreewidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'datatreewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DataTreeWidget_t {
    QByteArrayData data[18];
    char stringdata0[254];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DataTreeWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DataTreeWidget_t qt_meta_stringdata_DataTreeWidget = {
    {
QT_MOC_LITERAL(0, 0, 14), // "DataTreeWidget"
QT_MOC_LITERAL(1, 15, 10), // "SaveSource"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 12), // "SaveAsSource"
QT_MOC_LITERAL(4, 40, 12), // "RemoveSource"
QT_MOC_LITERAL(5, 53, 15), // "AddBikeAnalysis"
QT_MOC_LITERAL(6, 69, 14), // "AddCarAnalysis"
QT_MOC_LITERAL(7, 84, 16), // "AnalysisSettings"
QT_MOC_LITERAL(8, 101, 14), // "UpdateAnalysis"
QT_MOC_LITERAL(9, 116, 16), // "OnRemoveAnalysis"
QT_MOC_LITERAL(10, 133, 15), // "OnSourceRemoved"
QT_MOC_LITERAL(11, 149, 6), // "Source"
QT_MOC_LITERAL(12, 156, 13), // "OnSourceAdded"
QT_MOC_LITERAL(13, 170, 17), // "OnChildrenUpdated"
QT_MOC_LITERAL(14, 188, 13), // "OnDataUpdated"
QT_MOC_LITERAL(15, 202, 17), // "OnMetaDataUpdated"
QT_MOC_LITERAL(16, 220, 15), // "OnSeriesUpdated"
QT_MOC_LITERAL(17, 236, 17) // "OnAnalysesUpdated"

    },
    "DataTreeWidget\0SaveSource\0\0SaveAsSource\0"
    "RemoveSource\0AddBikeAnalysis\0"
    "AddCarAnalysis\0AnalysisSettings\0"
    "UpdateAnalysis\0OnRemoveAnalysis\0"
    "OnSourceRemoved\0Source\0OnSourceAdded\0"
    "OnChildrenUpdated\0OnDataUpdated\0"
    "OnMetaDataUpdated\0OnSeriesUpdated\0"
    "OnAnalysesUpdated"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DataTreeWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   89,    2, 0x0a /* Public */,
       3,    0,   90,    2, 0x0a /* Public */,
       4,    0,   91,    2, 0x0a /* Public */,
       5,    0,   92,    2, 0x0a /* Public */,
       6,    0,   93,    2, 0x0a /* Public */,
       7,    0,   94,    2, 0x0a /* Public */,
       8,    0,   95,    2, 0x0a /* Public */,
       9,    0,   96,    2, 0x09 /* Protected */,
      10,    1,   97,    2, 0x09 /* Protected */,
      12,    1,  100,    2, 0x09 /* Protected */,
      13,    1,  103,    2, 0x09 /* Protected */,
      14,    1,  106,    2, 0x09 /* Protected */,
      15,    1,  109,    2, 0x09 /* Protected */,
      16,    1,  112,    2, 0x09 /* Protected */,
      17,    1,  115,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QStringList,   11,
    QMetaType::Void, QMetaType::QStringList,   11,
    QMetaType::Void, QMetaType::QStringList,   11,
    QMetaType::Void, QMetaType::QStringList,   11,
    QMetaType::Void, QMetaType::QStringList,   11,
    QMetaType::Void, QMetaType::QStringList,   11,
    QMetaType::Void, QMetaType::QStringList,   11,

       0        // eod
};

void DataTreeWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DataTreeWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SaveSource(); break;
        case 1: _t->SaveAsSource(); break;
        case 2: _t->RemoveSource(); break;
        case 3: _t->AddBikeAnalysis(); break;
        case 4: _t->AddCarAnalysis(); break;
        case 5: _t->AnalysisSettings(); break;
        case 6: _t->UpdateAnalysis(); break;
        case 7: _t->OnRemoveAnalysis(); break;
        case 8: _t->OnSourceRemoved((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 9: _t->OnSourceAdded((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 10: _t->OnChildrenUpdated((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 11: _t->OnDataUpdated((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 12: _t->OnMetaDataUpdated((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 13: _t->OnSeriesUpdated((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 14: _t->OnAnalysesUpdated((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject DataTreeWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<LAWTreeWidget::staticMetaObject>(),
    qt_meta_stringdata_DataTreeWidget.data,
    qt_meta_data_DataTreeWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *DataTreeWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DataTreeWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DataTreeWidget.stringdata0))
        return static_cast<void*>(this);
    return LAWTreeWidget::qt_metacast(_clname);
}

int DataTreeWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LAWTreeWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
